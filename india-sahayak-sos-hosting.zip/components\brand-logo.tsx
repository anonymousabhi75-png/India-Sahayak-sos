import Image from 'next/image'

/**
 * Shows only the India Sahayak logo mark cropped out of the source photo
 * (the full photo has a large white paper margin we don't want on the site).
 * The mark sits roughly in the horizontal center of the source image, so we
 * scale up and clip the surrounding whitespace with a fixed-size window.
 */
export function BrandLogo({
  className = 'h-12 w-12',
  withText = false,
}: {
  className?: string
  withText?: boolean
}) {
  if (withText) {
    // Taller crop that keeps the emblem, the stylized mark and the wordmark.
    return (
      <div className={`relative overflow-hidden ${className}`} style={{ aspectRatio: '1 / 1' }}>
        <Image
          src="/india-sahayak-logo.jpeg"
          alt="India Sahayak logo"
          fill
          priority
          sizes="200px"
          className="object-cover"
          style={{ objectPosition: '50% 42%', transform: 'scale(1.7)' }}
        />
      </div>
    )
  }

  // Compact badge: crop tight to just the emblem + stylized "i" mark.
  return (
    <div
      className={`relative overflow-hidden rounded-xl bg-white ${className}`}
    >
      <Image
        src="/india-sahayak-logo.jpeg"
        alt="India Sahayak logo"
        fill
        priority
        sizes="96px"
        className="object-cover"
        style={{ objectPosition: '50% 30%', transform: 'scale(2.3)' }}
      />
    </div>
  )
}
