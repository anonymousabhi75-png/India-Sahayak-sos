import { Users, HeartPulse, MapPin, Send, ClipboardCheck, ShieldCheck } from 'lucide-react'

export function ActionDesk() {
  return (
    <section className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-6 w-6 text-primary" />
            <h2 className="text-2xl font-bold tracking-tight">Resident action desk</h2>
            <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-0.5 font-mono text-[10px] tracking-[0.12em] text-emerald-300">
              CONSENT-FIRST
            </span>
          </div>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Turn city signals into a safer household, a trackable complaint, or a fast help request.
          </p>
        </div>
        <span className="inline-flex items-center gap-1.5 font-mono text-[11px] tracking-[0.12em] text-emerald-300">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> CONNECTED
        </span>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        {/* Household report card */}
        <article className="rounded-2xl border border-border/80 bg-card p-6">
          <div className="flex items-start justify-between">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-secondary">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-0.5 font-mono text-[10px] tracking-[0.12em] text-emerald-300">
              READY
            </span>
          </div>
          <h3 className="mt-5 text-lg font-bold">Household report card</h3>
          <p className="mt-1 text-sm text-muted-foreground">Aarav Demo · 1 household member</p>
          <button className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl border border-border/70 bg-background/40 px-4 py-3 text-sm font-semibold transition-colors hover:border-primary/40">
            <ClipboardCheck className="h-4 w-4" />
            Edit report card
          </button>
        </article>

        {/* Blood & donation match */}
        <article className="rounded-2xl border border-border/80 bg-card p-6">
          <div className="flex items-start justify-between">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-secondary">
              <HeartPulse className="h-5 w-5 text-rose-400" />
            </div>
            <span className="rounded-full border border-rose-400/30 bg-rose-400/10 px-2.5 py-0.5 font-mono text-[10px] tracking-[0.12em] text-rose-300">
              OPT-IN ONLY
            </span>
          </div>
          <h3 className="mt-5 text-lg font-bold">Blood &amp; donation match</h3>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
            Create a hospital request and surface masked, consented matches nearby. Mocked
            notifications stay in-app.
          </p>

          <div className="mt-5 space-y-3">
            <div className="flex gap-3">
              <div className="flex-1 rounded-lg border border-border/70 bg-background/40 px-3 py-2 text-sm">
                A-
              </div>
              <div className="flex-1 rounded-lg border border-border/70 bg-background/40 px-3 py-2 text-sm text-muted-foreground">
                Whole blood
              </div>
            </div>
            <button className="flex w-full items-center justify-center gap-2 rounded-xl bg-rose-400/90 px-4 py-3 text-sm font-semibold text-rose-950 transition-transform hover:scale-[1.01]">
              <Send className="h-4 w-4" />
              Find opt-in matches
            </button>
          </div>

          <div className="mt-4 rounded-xl border border-border/60 bg-background/40 p-4">
            <p className="text-sm font-semibold">
              2 matches · <span className="text-emerald-300">A-</span>
            </p>
            <div className="mt-3 space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">
                  Opt-in donor A · <span className="font-mono text-xs">2.4 km</span>
                </span>
                <span className="font-mono text-emerald-300">+91 ···· 4812</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">
                  Opt-in donor B · <span className="font-mono text-xs">6.8 km</span>
                </span>
                <span className="font-mono text-emerald-300">+91 ···· 9034</span>
              </div>
            </div>
            <p className="mt-3 text-xs leading-relaxed text-amber-300/80">
              Demo matching only; real notifications require verified donor consent and a production
              messaging provider.
            </p>
          </div>
        </article>

        {/* Report a city problem */}
        <article className="rounded-2xl border border-border/80 bg-card p-6">
          <div className="flex items-start justify-between">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-secondary">
              <MapPin className="h-5 w-5 text-amber-300" />
            </div>
            <span className="rounded-full border border-amber-400/30 bg-amber-400/10 px-2.5 py-0.5 font-mono text-[10px] tracking-[0.12em] text-amber-300">
              CITYPULSE QUEUE
            </span>
          </div>
          <h3 className="mt-5 text-lg font-bold">Report a city problem</h3>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
            Road, electricity, water, sanitation, or safety issue? Add context and a photo filename
            for review.
          </p>

          <div className="mt-5 space-y-3">
            <div className="rounded-lg border border-border/70 bg-background/40 px-3 py-2 text-sm">
              Water
            </div>
            <div className="rounded-lg border border-border/70 bg-background/40 px-3 py-2 text-sm text-muted-foreground">
              Short title
            </div>
            <div className="rounded-lg border border-border/70 bg-background/40 px-3 py-2 text-sm text-muted-foreground">
              Location / landmark
            </div>
            <div className="rounded-lg border border-border/70 bg-background/40 px-3 py-6 text-sm text-muted-foreground">
              What happened?
            </div>
            <button className="flex w-full items-center justify-center gap-2 rounded-xl bg-amber-400/90 px-4 py-3 text-sm font-semibold text-amber-950 transition-transform hover:scale-[1.01]">
              <ClipboardCheck className="h-4 w-4" />
              Submit city complaint
            </button>
          </div>
        </article>
      </div>
    </section>
  )
}
