'use client'

import { FormEvent, useState } from 'react'
import {
  CarFront,
  CloudRain,
  Compass,
  Download,
  LocateFixed,
  MapPin,
  Search,
  ShieldAlert,
  Wind,
  Zap,
} from 'lucide-react'

type Marker = { x: number; y: number; tone: string; label: string }

const markers: Marker[] = [
  { x: 27, y: 37, tone: '#fb4b5f', label: 'Traffic incident' },
  { x: 68, y: 27, tone: '#f6b73c', label: 'Rain watch' },
  { x: 57, y: 70, tone: '#55d6be', label: 'Emergency help' },
  { x: 79, y: 58, tone: '#fb4b5f', label: 'Accident report' },
  { x: 38, y: 73, tone: '#63a8ff', label: 'Flood watch' },
]

export function LiveMap() {
  const [query, setQuery] = useState('Delhi NCR')
  const [location, setLocation] = useState('Delhi NCR')
  const [coordinates, setCoordinates] = useState({ latitude: 28.6139, longitude: 77.209 })
  const [mapStatus, setMapStatus] = useState('')
  const [bluetooth, setBluetooth] = useState(false)
  const [mapMode, setMapMode] = useState<'satellite' | 'street'>('satellite')
  const zoom = 10
  const tileScale = 2 ** zoom
  const tileX = Math.floor(((coordinates.longitude + 180) / 360) * tileScale)
  const tileY = Math.floor((1 - Math.asinh(Math.tan((coordinates.latitude * Math.PI) / 180)) / Math.PI) / 2 * tileScale)
  const satelliteTiles = Array.from({ length: 3 }, (_, row) =>
    Array.from({ length: 3 }, (_, column) => {
      const x = tileX + column - 1
      const y = tileY + row - 1
      return {
        key: `${x}-${y}`,
        src: `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${zoom}/${y}/${x}`,
        left: `${column * 50 - 50}%`,
        top: `${row * 50 - 50}%`,
      }
    }),
  ).flat()

  const updateMap = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const nextLocation = query.trim()
    if (!nextLocation) return
    setLocation(nextLocation)
    setMapStatus('Finding this place…')
    void fetch(`https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=in&q=${encodeURIComponent(nextLocation)}`)
      .then(async (response) => {
        if (!response.ok) throw new Error('Location search failed')
        const results = await response.json() as Array<{ lat: string; lon: string; display_name: string }>
        const result = results[0]
        if (!result) throw new Error('Place not found')
        setCoordinates({ latitude: Number(result.lat), longitude: Number(result.lon) })
        setLocation(result.display_name.split(',').slice(0, 2).join(','))
        setMapStatus('Satellite map updated for this location')
      })
      .catch(() => setMapStatus('Place not found. Try a city, landmark, or locality in India.'))
  }

  const locateMe = () => {
    if (!navigator.geolocation) {
      setMapStatus('Location is not supported by this browser')
      return
    }
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        setCoordinates({ latitude: coords.latitude, longitude: coords.longitude })
        setLocation('My live location')
        setMapStatus(`Live position updated at ${new Date().toLocaleTimeString()}`)
      },
      () => setMapStatus('Location permission was denied'),
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 10000 },
    )
  }

  const downloadMapData = () => {
    const data = { location, updatedAt: new Date().toISOString(), markers, note: 'Illustrative operations layer; connect approved feeds for official data.' }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `${location.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-citypulse-map-data.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const interactiveMap = `https://www.openstreetmap.org/export/embed.html?bbox=${coordinates.longitude - 0.12}%2C${coordinates.latitude - 0.09}%2C${coordinates.longitude + 0.12}%2C${coordinates.latitude + 0.09}&layer=mapnik&marker=${coordinates.latitude}%2C${coordinates.longitude}`
  const satelliteViewer = `https://www.arcgis.com/apps/mapviewer/index.html?center=${coordinates.longitude}%2C${coordinates.latitude}&level=12&basemap=satellite`

  return (
    <section className="space-y-5">
      <div>
        <p className="font-mono text-[10px] tracking-[0.18em] text-primary">CITY OPERATIONS MAP</p>
        <h2 className="mt-1 text-2xl font-bold tracking-tight">See alerts around you</h2>
        <p className="mt-1.5 text-sm text-muted-foreground">A visible satellite-style operations view for routes, incidents, weather and emergency layers.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-[1.35fr_.65fr]">
        <div className="overflow-hidden rounded-2xl border border-border/80 bg-card">
          <form onSubmit={updateMap} className="flex gap-2 border-b border-border/70 p-3">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search city or locality" className="h-10 w-full rounded-lg border border-border/70 bg-background/50 pl-10 pr-3 text-sm outline-none focus:border-primary/50" />
            </div>
            <button type="submit" className="rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground">Update map</button>
          </form>
          {mapStatus && <p className="border-b border-border/70 px-3 py-2 text-xs text-emerald-300">{mapStatus}</p>}

          <div className="relative h-[330px] overflow-hidden bg-slate-900 sm:h-[390px]" aria-label={`${mapMode} map for ${location}`}>
            {mapMode === 'satellite' ? <div className="absolute inset-0 overflow-hidden bg-slate-900" aria-label={`Satellite imagery of ${location}`}>{satelliteTiles.map((tile) => <img key={tile.key} src={tile.src} alt="" className="absolute h-1/2 w-1/2 max-w-none object-cover" style={{ left: tile.left, top: tile.top }} />)}</div> : <iframe title={`Interactive map of ${location}`} className="h-full w-full border-0" src={interactiveMap} />}
            <div className="absolute left-3 top-3 rounded-lg border border-white/15 bg-slate-950/80 px-3 py-2 text-xs text-white backdrop-blur"><MapPin className="mr-1 inline h-3.5 w-3.5 text-primary" />{location}<span className="ml-2 font-mono text-[9px] text-emerald-300">{mapMode === 'satellite' ? 'SATELLITE' : 'INTERACTIVE MAP'}</span></div>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border/70 px-4 py-3 text-xs text-muted-foreground"><span><strong className="text-foreground">{location}</strong> · {mapMode} view</span><div className="flex flex-wrap gap-3"><button type="button" onClick={locateMe} className="inline-flex items-center gap-1.5 font-semibold text-primary"><LocateFixed className="h-3.5 w-3.5" />Locate me</button><button type="button" onClick={() => setMapMode((mode) => mode === 'satellite' ? 'street' : 'satellite')} className="font-semibold text-primary">{mapMode === 'satellite' ? 'Open interactive map' : 'Show satellite view'}</button><a href={satelliteViewer} target="_blank" rel="noreferrer" className="font-semibold text-primary">Full satellite</a><button type="button" onClick={downloadMapData} className="inline-flex items-center gap-1.5 font-semibold text-primary"><Download className="h-3.5 w-3.5" />Save emergency map</button></div></div>
        </div>

        <div className="space-y-3 rounded-2xl border border-border/80 bg-card p-4">
          <div className="flex items-center gap-2 text-sm font-bold"><LocateFixed className="h-4 w-4 text-primary" /> Live operations layers</div>
          <div className="rounded-xl border border-primary/25 bg-primary/10 p-3"><div className="flex items-center gap-2 text-sm font-semibold"><Compass className="h-4 w-4 text-primary" />Best route</div><p className="mt-1 text-xs text-muted-foreground">Fastest route · 24 min · moderate traffic</p></div>
          {[['Traffic & accidents', CarFront, 'Moderate traffic · 2 reports'], ['Weather & rain', CloudRain, '28°C · rain chance 30%'], ['Flood watch', CloudRain, 'No active warning shown'], ['Wind conditions', Wind, '14 km/h · clear visibility'], ['Power status', Zap, 'No planned outage shown'], ['Emergency help', ShieldAlert, 'Police, fire and ambulance']].map(([label, Icon, detail]) => <div key={label as string} className="rounded-xl border border-border/70 bg-background/35 p-3"><div className="flex items-center gap-2 text-sm font-semibold"><Icon className="h-4 w-4 text-primary" />{label}</div><p className="mt-1 text-xs text-muted-foreground">{detail}</p></div>)}
          <button type="button" onClick={() => setBluetooth((value) => !value)} className={`w-full rounded-xl border px-3 py-2 text-left text-xs ${bluetooth ? 'border-emerald-400/50 bg-emerald-400/10 text-emerald-300' : 'border-border/70 text-muted-foreground'}`}>{bluetooth ? 'Bluetooth safety sharing enabled for this browser' : 'Enable opt-in Bluetooth safety sharing'}</button>
          <p className="text-[10px] leading-relaxed text-muted-foreground">The map is interactive when online. Accident, road, and emergency alerts require approved live government or municipal feeds; the dashboard does not invent alerts. Offline mode caches this app and saves a location snapshot.</p>
        </div>
      </div>
    </section>
  )
}
