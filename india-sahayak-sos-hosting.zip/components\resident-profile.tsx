'use client'

import { useEffect, useState } from 'react'
import { CheckCircle2, ChevronDown, HeartPulse, LockKeyhole, ShieldCheck, UserRound } from 'lucide-react'

export function ResidentProfile() {
  const [saved, setSaved] = useState(false)
  const [expanded, setExpanded] = useState(false)
  const [profile, setProfile] = useState({ name: '', bloodGroup: '', allergies: '' })

  useEffect(() => {
    const savedProfile = localStorage.getItem('india-sahayak-care-profile')
    if (savedProfile) {
      try {
        setProfile(JSON.parse(savedProfile))
        setSaved(true)
      } catch {
        localStorage.removeItem('india-sahayak-care-profile')
      }
    }
  }, [])

  return (
    <section className={`profile-shell relative overflow-hidden rounded-3xl border border-primary/20 bg-card p-5 shadow-2xl shadow-cyan-950/20 transition-all sm:p-8 ${expanded ? '' : 'cursor-pointer'}`}>
      <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
      <div
        className="relative flex items-center justify-between gap-4"
        onClick={() => {
          if (!expanded) setExpanded(true)
        }}
      >
        <div className="flex items-center gap-3">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-primary/15 text-primary">
            {saved ? <CheckCircle2 className="h-5 w-5" /> : <UserRound className="h-5 w-5" />}
          </div>
          <div>
            <p className="font-mono text-[10px] tracking-[0.18em] text-primary">
              {saved ? 'PROFILE READY' : 'WELCOME DESK'}
            </p>
            <h2 className="mt-1 text-xl font-bold tracking-tight sm:text-2xl">
              {saved && profile.name ? `Hello, ${profile.name}` : 'Create your care profile'}
            </h2>
            {saved && (
              <p className="mt-1 text-xs text-muted-foreground">
                {profile.bloodGroup || 'Blood group not added'} · {profile.allergies || 'No allergies listed'}
              </p>
            )}
          </div>
        </div>
        <button
          type="button"
          aria-expanded={expanded}
          onClick={() => setExpanded((value) => !value)}
          className="inline-flex shrink-0 items-center gap-2 rounded-full border border-border/70 bg-background/40 px-3 py-2 text-xs font-semibold text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground"
        >
          {expanded ? 'Close' : saved ? 'Edit profile' : 'Open'}
          <ChevronDown className={`h-4 w-4 transition-transform ${expanded ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {expanded && (
        <div className="relative mt-8 grid gap-8 lg:grid-cols-[1fr_1.2fr] lg:items-center">
        <div>
          <div className="flex items-center gap-3">
            <div>
              <h3 className="text-lg font-bold tracking-tight">Your emergency essentials</h3>
            </div>
          </div>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted-foreground">
            Add essential details once to make emergency guidance faster and more relevant. This
            demo keeps your profile on this device only.
          </p>
          <div className="mt-5 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2 lg:grid-cols-1">
            <span className="inline-flex items-center gap-2"><LockKeyhole className="h-3.5 w-3.5 text-primary" /> Aadhaar is masked and never displayed in full</span>
            <span className="inline-flex items-center gap-2"><ShieldCheck className="h-3.5 w-3.5 text-emerald-300" /> Not connected to any government database</span>
          </div>
        </div>

        <form
          className="grid gap-4 sm:grid-cols-2"
          onSubmit={(event) => {
            event.preventDefault()
            setSaved(true)
            localStorage.setItem('india-sahayak-care-profile', JSON.stringify(profile))
            setExpanded(false)
          }}
        >
          <label className="field-label">Full name<input required name="name" placeholder="Enter your name" onChange={(event) => setProfile({ ...profile, name: event.target.value })} /></label>
          <label className="field-label">Mobile number<input required name="mobile" inputMode="tel" placeholder="+91 98765 43210" /></label>
          <label className="field-label">Aadhaar number <span className="font-normal text-muted-foreground">(optional)</span><input name="aadhaar" inputMode="numeric" maxLength={12} placeholder="XXXX XXXX XXXX" /></label>
          <label className="field-label">Blood group<select required name="bloodGroup" defaultValue="" onChange={(event) => setProfile({ ...profile, bloodGroup: event.target.value })}><option value="" disabled>Select group</option><option>A+</option><option>A-</option><option>B+</option><option>B-</option><option>AB+</option><option>AB-</option><option>O+</option><option>O-</option></select></label>
          <label className="field-label sm:col-span-2">Known allergies <span className="font-normal text-muted-foreground">(optional)</span><input name="allergies" placeholder="e.g. penicillin, dust, none" onChange={(event) => setProfile({ ...profile, allergies: event.target.value })} /></label>
          <button className="flex items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-bold text-primary-foreground transition-transform hover:scale-[1.01] sm:col-span-2" type="submit">
            {saved ? <><CheckCircle2 className="h-4 w-4" /> Profile saved on this device</> : <><HeartPulse className="h-4 w-4" /> Save my care profile</>}
          </button>
        </form>
        </div>
      )}
    </section>
  )
}
