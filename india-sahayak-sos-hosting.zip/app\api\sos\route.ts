import { NextResponse } from 'next/server'

export async function POST(request: Request) {
  const webhookUrl = process.env.POWER_AUTOMATE_SOS_WEBHOOK_URL
  if (!webhookUrl) {
    return NextResponse.json({ registered: false, reason: 'Spreadsheet webhook is not configured' }, { status: 503 })
  }

  const body = await request.json()
  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...body,
      receivedAt: new Date().toISOString(),
      source: 'India Sahayak',
    }),
  })

  if (!response.ok) {
    return NextResponse.json({ registered: false, reason: 'Spreadsheet service rejected the event' }, { status: 502 })
  }
  return NextResponse.json({ registered: true })
}
