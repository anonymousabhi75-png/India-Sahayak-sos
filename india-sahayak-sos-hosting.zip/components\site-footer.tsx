import { ClipboardCheck } from 'lucide-react'

export function SiteFooter() {
  return (
    <footer className="mt-4 border-t border-border/70 pt-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <ClipboardCheck className="h-4 w-4 text-primary" />
          1 saved CityPulse complaint
        </p>
        <span className="font-mono text-[10px] tracking-[0.14em] text-muted-foreground">
          OFFICIAL CONNECTOR: NOT CONFIGURED
        </span>
      </div>
      <p className="mt-6 text-xs text-muted-foreground">
        CityPulse India · Experimental civic intelligence for the AmiHacks CityPulse track. Built
        with India Sahayak.
      </p>
    </footer>
  )
}
