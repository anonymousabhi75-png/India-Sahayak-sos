'use client'

import { useEffect, useRef, useState } from 'react'
import { ShieldAlert, Phone, BellRing, WifiOff, MapPin, Download, Share2 } from 'lucide-react'

type EmergencyLocation = {
  latitude: number
  longitude: number
  accuracy: number
  capturedAt: string
}

type CareProfile = { name: string; bloodGroup?: string; allergies?: string }

async function registerWithOfficials(location: EmergencyLocation, eventType: 'SOS' | 'LIVE_LOCATION') {
  const savedProfile = localStorage.getItem('india-sahayak-care-profile')
  const profile = savedProfile ? JSON.parse(savedProfile) as CareProfile : null
  const response = await fetch('/api/sos', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ eventType, profile, location, mapUrl: `https://maps.google.com/?q=${location.latitude},${location.longitude}` }),
  })
  if (!response.ok) throw new Error('SOS registration was not accepted by the official spreadsheet service')
}

function saveLocationFile(location: EmergencyLocation) {
  const payload = {
    service: 'India Sahayak emergency location record',
    location,
    instructions: 'Share this file with emergency responders. Calling 112 is still required for dispatch.',
  }
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = `india-sahayak-sos-${location.capturedAt.replace(/[:.]/g, '-')}.json`
  link.click()
  URL.revokeObjectURL(url)
}

export function SosPanel() {
  const [location, setLocation] = useState<EmergencyLocation | null>(null)
  const [status, setStatus] = useState('Ready to capture your location')
  const [installPrompt, setInstallPrompt] = useState<Event | null>(null)
  const [isLive, setIsLive] = useState(false)
  const [online, setOnline] = useState(true)
  const [isInstalled, setIsInstalled] = useState(false)
  const [watchId, setWatchId] = useState<number | null>(null)
  const watchIdRef = useRef<number | null>(null)

  useEffect(() => {
    setOnline(navigator.onLine)
    setIsInstalled(window.matchMedia('(display-mode: standalone)').matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone))
    const onlineChanged = () => {
      setOnline(navigator.onLine)
      if (navigator.onLine) {
        const pending = JSON.parse(localStorage.getItem('india-sahayak-pending-sos') || '[]') as EmergencyLocation[]
        if (pending.length) {
          Promise.all(pending.map((item) => registerWithOfficials(item, 'LIVE_LOCATION')))
            .then(() => localStorage.removeItem('india-sahayak-pending-sos'))
            .catch(() => undefined)
        }
      }
    }
    window.addEventListener('online', onlineChanged)
    window.addEventListener('offline', onlineChanged)
    const handleInstall = (event: Event) => {
      event.preventDefault()
      setInstallPrompt(event)
    }
    window.addEventListener('beforeinstallprompt', handleInstall)
    const installed = () => {
      setInstallPrompt(null)
      setIsInstalled(true)
      setStatus('India Sahayak was added to your home screen')
    }
    window.addEventListener('appinstalled', installed)
    if ('serviceWorker' in navigator) {
      void navigator.serviceWorker.register('/sw.js')
    }
    const saved = localStorage.getItem('india-sahayak-last-sos')
    if (saved) {
      try {
        setLocation(JSON.parse(saved) as EmergencyLocation)
      } catch {
        localStorage.removeItem('india-sahayak-last-sos')
      }
    }
    return () => {
      window.removeEventListener('beforeinstallprompt', handleInstall)
      window.removeEventListener('online', onlineChanged)
      window.removeEventListener('offline', onlineChanged)
      window.removeEventListener('appinstalled', installed)
      if (watchIdRef.current !== null) navigator.geolocation?.clearWatch(watchIdRef.current)
    }
  }, [])

  const updateLocation = (position: GeolocationPosition, announce = true, download = announce) => {
    const nextLocation = {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: Math.round(position.coords.accuracy),
      capturedAt: new Date().toISOString(),
    }
    setLocation(nextLocation)
    localStorage.setItem('india-sahayak-last-sos', JSON.stringify(nextLocation))
    const history = JSON.parse(localStorage.getItem('india-sahayak-sos-history') || '[]') as EmergencyLocation[]
    localStorage.setItem('india-sahayak-sos-history', JSON.stringify([...history.slice(-49), nextLocation]))
    if (download) saveLocationFile(nextLocation)
    void registerWithOfficials(nextLocation, announce ? 'SOS' : 'LIVE_LOCATION').catch(() => {
      const pending = JSON.parse(localStorage.getItem('india-sahayak-pending-sos') || '[]') as unknown[]
      localStorage.setItem('india-sahayak-pending-sos', JSON.stringify([...pending.slice(-49), nextLocation]))
    })
    if (announce) setStatus('Location saved to this device and download started')
    return nextLocation
  }

  const captureAndShare = () => {
    if (!navigator.geolocation) {
      setStatus('Location is not supported by this browser')
      return
    }
    setStatus('Requesting precise location permission…')
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const nextLocation = updateLocation(position)
        if (navigator.share) {
          void navigator.share({
            title: 'India Sahayak emergency location',
            text: `Emergency location: ${nextLocation.latitude}, ${nextLocation.longitude}`,
            url: `https://maps.google.com/?q=${nextLocation.latitude},${nextLocation.longitude}`,
          }).catch(() => undefined)
        }
      },
      () => setStatus('Location permission was denied. Call 112 and share your location manually.'),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 },
    )
  }

  const toggleLiveSos = () => {
    if (!navigator.geolocation) {
      setStatus('Live location is not supported by this browser')
      return
    }
    if (isLive && watchId !== null) {
      navigator.geolocation.clearWatch(watchId)
      watchIdRef.current = null
      setWatchId(null)
      setIsLive(false)
      setStatus('Live SOS stopped. Your last location remains saved.')
      return
    }
    setStatus('Starting live SOS location sharing…')
    const id = navigator.geolocation.watchPosition(
      (position) => {
        updateLocation(position, false, false)
        setStatus(`LIVE SOS active · ${navigator.onLine ? 'location saved' : 'saved offline'} · updated ${new Date().toLocaleTimeString()}`)
      },
      () => {
        setIsLive(false)
        setWatchId(null)
        setStatus('Live location permission was denied. Call 112 immediately.')
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 },
    )
    setWatchId(id)
    watchIdRef.current = id
    setIsLive(true)
  }

  useEffect(() => {
    if (window.location.hash === '#sos') {
      const timer = window.setTimeout(() => toggleLiveSos(), 300)
      return () => window.clearTimeout(timer)
    }
  }, [])

  const installApp = async () => {
    if (isInstalled) {
      setStatus('India Sahayak is already installed. Open it from your device home screen.')
      return
    }
    if (!installPrompt) {
      setStatus('Open your browser menu and choose “Install app” or “Add to Home screen”, then approve it.')
      return
    }
    const prompt = installPrompt as Event & { prompt: () => Promise<void> }
    await prompt.prompt()
    setInstallPrompt(null)
  }

  return (
    <section id="sos" className="rounded-2xl border border-destructive/40 bg-card p-6 shadow-lg shadow-destructive/5 sm:p-8">
      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr] lg:items-center">
        <div>
          <div className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-destructive/15">
              <ShieldAlert className="h-5 w-5 text-destructive" />
            </div>
            <h2 className="text-2xl font-bold tracking-tight">SOS / urgent help</h2>
            <span className={`rounded-full border px-2.5 py-0.5 font-mono text-[10px] tracking-[0.12em] ${online ? 'border-emerald-400/30 bg-emerald-400/10 text-emerald-300' : 'border-amber-400/30 bg-amber-400/10 text-amber-300'}`}>
              {online ? 'CONNECTED' : 'OFFLINE / SAVING LOCALLY'}
            </span>
          </div>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted-foreground">
            From the installed home-screen SOS shortcut, live tracking starts automatically. It captures your precise location, saves an emergency record on this device, and shares a map link when connectivity is available.
            This browser cannot silently contact government control rooms; call 112 to dispatch help.
          </p>

          <div className="mt-5 rounded-xl border border-border/60 bg-background/40 p-4">
            <p className="flex items-center gap-2 text-sm font-semibold">
              <BellRing className="h-4 w-4 text-primary" />
              {status}
            </p>
            <p className="mt-1.5 text-sm text-muted-foreground">
              {location ? `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)} · ±${location.accuracy}m` : 'Location is only collected after you press the button and grant permission.'}
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <button type="button" onClick={captureAndShare} className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-rose-500 to-rose-400 px-4 py-4 text-base font-bold text-white transition-transform hover:scale-[1.01]">
            <MapPin className="h-5 w-5" />
            SOS: save & share my location
          </button>
          <button type="button" onClick={toggleLiveSos} className={`flex w-full items-center justify-center gap-2 rounded-xl border px-4 py-3.5 text-sm font-bold ${isLive ? 'border-emerald-400/60 bg-emerald-400/15 text-emerald-300' : 'border-destructive/50 bg-destructive/10 text-destructive'}`}>
            <span className={`h-2.5 w-2.5 rounded-full ${isLive ? 'animate-pulse bg-emerald-300' : 'bg-destructive'}`} />
            {isLive ? 'Stop live SOS tracking' : 'Start live SOS tracking'}
          </button>
          <a
            href="tel:112"
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-rose-500 to-rose-400 px-4 py-4 text-base font-bold text-white transition-transform hover:scale-[1.01]"
          >
            <ShieldAlert className="h-5 w-5" />
            Call 112 emergency
          </a>
          <a
            href="tel:100"
            className="flex w-full items-center justify-center gap-2 rounded-xl border border-border/70 bg-background/40 px-4 py-3.5 text-sm font-semibold transition-colors hover:border-primary/40"
          >
            <Phone className="h-4 w-4" />
            Call police 100
          </a>
          <button type="button" onClick={() => location && saveLocationFile(location)} disabled={!location} className="flex w-full items-center justify-center gap-2 rounded-xl border border-border/70 px-4 py-3 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-40">
            <Download className="h-4 w-4" /> Download saved location
          </button>
          <button type="button" onClick={installApp} className="flex w-full items-center justify-center gap-2 rounded-xl border border-primary/40 bg-primary/10 px-4 py-3 text-sm font-semibold text-primary">
            <Share2 className="h-4 w-4" /> {isInstalled ? 'App installed on this device' : 'Install app on home screen'}
          </button>
        </div>
      </div>

      <div className="mt-6 flex items-center gap-2 border-t border-border/60 pt-4 font-mono text-[10px] tracking-[0.1em] text-muted-foreground">
        <WifiOff className="h-3.5 w-3.5" />
        <span>Location records stay local unless you choose to share them. A website cannot guarantee emergency delivery without a connected official backend.</span>
      </div>
    </section>
  )
}
