import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/hero'
import { CityServices } from '@/components/city-services'
import { SosPanel } from '@/components/sos-panel'
import { SiteFooter } from '@/components/site-footer'
import { ResidentProfile } from '@/components/resident-profile'
import { CityInsights } from '@/components/city-insights'
import { OfficialDesk } from '@/components/official-desk'
import { SocialPoints } from '@/components/social-points'
import { LiveMap } from '@/components/live-map'
import { ShieldAlert } from 'lucide-react'

export default function Page() {
  return (
    <div id="top" className="min-h-screen bg-background">
      <SiteHeader />
      <main className="mx-auto max-w-7xl space-y-8 px-4 py-6 sm:px-6 sm:py-8">
        <Hero />
        <ResidentProfile />
        <CityInsights />
        <LiveMap />
        <CityServices />
        <OfficialDesk />
        <SosPanel />
        <SocialPoints />
        <SiteFooter />
      </main>
        <a href="#sos" aria-label="Open SOS emergency controls" className="fixed bottom-5 right-5 z-50 inline-flex items-center gap-2 rounded-full bg-rose-500 px-5 py-3.5 text-sm font-bold text-white shadow-xl shadow-rose-950/40 transition-transform hover:scale-105">
          <ShieldAlert className="h-5 w-5" />
          SOS
        </a>
    </div>
  )
}
