import { Bell, MapPin, Megaphone } from 'lucide-react'

const nodes = [
  { x: 12, y: 30, s: 'watch' },
  { x: 40, y: 28, s: 'watch' },
  { x: 68, y: 30, s: 'watch' },
  { x: 12, y: 78, s: 'watch' },
  { x: 40, y: 80, s: 'watch' },
  { x: 68, y: 78, s: 'watch' },
]

const alerts = [
  {
    title: 'Air quality watch',
    tag: 'WARNING',
    tagColor: 'text-amber-300',
    dot: 'bg-amber-400',
    body: 'AQI is 169 (poor). Consider reducing prolonged outdoor exposure.',
    source: 'Open-Meteo Air Quality',
  },
  {
    title: 'Stay aware of changing conditions',
    tag: 'ADVISORY',
    tagColor: 'text-primary',
    dot: 'bg-primary',
    body: 'City signals are informational. Check official sources before making emergency decisions.',
    source: 'CityPulse safety desk · demo',
  },
]

export function PulsePanel() {
  return (
    <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
      {/* Neighborhood pulse map */}
      <section className="rounded-2xl border border-border/80 bg-card p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight">Neighborhood pulse map</h2>
              <span className="rounded-full border border-primary/30 bg-primary/10 px-2.5 py-0.5 font-mono text-[10px] tracking-[0.12em] text-primary">
                SDK-FREE RADAR
              </span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">
              Signal topology across Delhi NCR sectors · tap a node for context
            </p>
          </div>
          <div className="flex items-center gap-4 font-mono text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />steady
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-amber-400" />watch
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-destructive" />alert
            </span>
          </div>
        </div>

        <div className="relative mt-6 h-64 overflow-hidden rounded-xl border border-border/60 bg-background/40">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage:
                'linear-gradient(oklch(1 0 0 / 0.05) 1px, transparent 1px), linear-gradient(90deg, oklch(1 0 0 / 0.05) 1px, transparent 1px)',
              backgroundSize: '48px 48px',
            }}
          />
          <div className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2 rounded-full border border-primary/20" />
          <div className="absolute left-1/2 top-1/2 h-24 w-24 -translate-x-1/2 -translate-y-1/2 rounded-full border border-primary/15" />
          {nodes.map((n, i) => (
            <span
              key={i}
              className="absolute grid h-4 w-4 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-amber-400/20"
              style={{ left: `${n.x}%`, top: `${n.y}%` }}
            >
              <span className="h-2 w-2 rounded-full bg-amber-400" />
            </span>
          ))}
          <span className="absolute bottom-3 left-4 font-mono text-[10px] tracking-[0.16em] text-muted-foreground">
            DELHI NCR / LIVE TOPOLOGY
          </span>
        </div>
      </section>

      {/* Alert center */}
      <section className="rounded-2xl border border-border/80 bg-card p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-bold tracking-tight">Alert center</h2>
          </div>
          <span className="rounded-full bg-secondary px-2.5 py-1 text-xs font-semibold text-muted-foreground">
            2 open
          </span>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">Signals that may matter to residents</p>

        <div className="mt-4 space-y-3">
          {alerts.map((a) => (
            <div key={a.title} className="rounded-xl border border-border/60 bg-background/40 p-4">
              <div className="flex items-start gap-2">
                <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${a.dot}`} />
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-semibold">{a.title}</p>
                    <span className={`font-mono text-[10px] tracking-[0.12em] ${a.tagColor}`}>
                      {a.tag}
                    </span>
                  </div>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{a.body}</p>
                  <p className="mt-2 flex items-center gap-1.5 font-mono text-[10px] text-muted-foreground">
                    <MapPin className="h-3 w-3" /> {a.source}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.01]">
          <Megaphone className="h-4 w-4" />
          Run emergency broadcast drill
        </button>
        <p className="mt-2 text-center font-mono text-[10px] text-muted-foreground">
          Demo only · never a replacement for official emergency services
        </p>
      </section>
    </div>
  )
}
