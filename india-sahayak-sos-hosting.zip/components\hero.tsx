'use client'

import { useState } from 'react'
import { ArrowRight, ChevronDown, Clock3, MapPin, ShieldAlert } from 'lucide-react'
import { BrandLogo } from '@/components/brand-logo'

const cities = ['Delhi NCR', 'Mumbai', 'Bengaluru', 'Hyderabad', 'Kolkata', 'Chennai', 'Pune']

export function Hero() {
  const [city, setCity] = useState(cities[0])
  const [open, setOpen] = useState(false)

  return (
    <section className="space-y-4">
      <div className="gov-tricolor h-1.5 rounded-full" />
      <div className="flex flex-col gap-3 rounded-xl border border-destructive/25 bg-destructive/[0.07] px-5 py-3.5 sm:flex-row sm:items-center">
        <ShieldAlert className="h-5 w-5 shrink-0 text-destructive/90" />
        <p className="text-sm leading-relaxed text-muted-foreground"><span className="font-semibold text-foreground">Emergency information:</span> This is a civic-information directory. For immediate danger, call 112.</p>
        <span className="ml-auto shrink-0 font-mono text-[10px] tracking-[0.14em] text-destructive/80">24×7 EMERGENCY</span>
      </div>

      <div className="gov-hero overflow-hidden rounded-2xl border border-border/80 shadow-2xl shadow-black/20">
        <div className="border-b border-slate-200/10 px-5 py-4 sm:px-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="rounded-lg bg-white p-1.5 shadow-lg"><BrandLogo className="h-14 w-14" /></div>
              <div>
                <p className="text-xl font-bold tracking-tight text-white">INDIA <span className="text-orange-300">SAHAYAK</span></p>
                <p className="mt-1 text-[10px] font-medium tracking-[0.18em] text-slate-300">NATIONAL CIVIC ASSISTANCE PLATFORM</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-300"><Clock3 className="h-4 w-4 text-emerald-300" /> Services available 24×7</div>
          </div>
        </div>

        <div className="grid gap-8 px-5 py-8 sm:px-8 sm:py-10 lg:grid-cols-[1.2fr_.8fr] lg:items-center">
          <div>
            <p className="text-3xl font-semibold tracking-tight text-cyan-200 sm:text-4xl">नमस्ते</p>
            <p className="font-mono text-[10px] tracking-[0.18em] text-cyan-300">CITIZEN INFORMATION & SERVICES</p>
            <h1 className="mt-2 max-w-xl text-xl font-semibold leading-snug tracking-[-0.02em] text-white sm:text-3xl">Your city, <span className="text-cyan-200">your safety.</span><br /><span className="text-slate-200">One trusted civic pulse.</span></h1>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-slate-300">Move with clarity through official services, live location tools, emergency help, public updates and civic resources — all in one place.</p>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <a href="#sos" className="inline-flex items-center gap-2 rounded-lg bg-rose-500 px-5 py-3 text-sm font-bold text-white transition-colors hover:bg-rose-400"><ShieldAlert className="h-4 w-4" /> SOS / share location</a>
              <a href="#services" className="inline-flex items-center gap-2 rounded-lg bg-orange-500 px-5 py-3 text-sm font-bold text-white transition-colors hover:bg-orange-400">View citizen services <ArrowRight className="h-4 w-4" /></a>
              <div className="relative">
                <button type="button" onClick={() => setOpen((value) => !value)} className="inline-flex items-center gap-2 rounded-lg border border-slate-500/60 bg-slate-900/40 px-4 py-3 text-sm font-semibold text-white"><MapPin className="h-4 w-4 text-emerald-300" /> {city} <ChevronDown className={`h-4 w-4 transition-transform ${open ? 'rotate-180' : ''}`} /></button>
                {open && <div className="absolute left-0 top-14 z-30 w-52 rounded-xl border border-border bg-card p-2 shadow-2xl">{cities.map((option) => <button key={option} type="button" onClick={() => { setCity(option); setOpen(false) }} className="block w-full rounded-lg px-3 py-2.5 text-left text-sm text-foreground transition-colors hover:bg-secondary">{option}</button>)}</div>}
              </div>
            </div>
          </div>
          <div className="rounded-2xl border border-slate-500/40 bg-slate-950/35 p-5">
            <div className="flex items-center gap-3 border-b border-slate-500/30 pb-4"><BrandLogo className="h-12 w-12" /><div><p className="text-sm font-bold text-white">Citizen service desk</p><p className="mt-1 text-xs text-slate-400">Selected location: {city}</p></div></div>
            <div className="mt-5 grid grid-cols-2 gap-3 text-center"><div className="rounded-xl bg-slate-900/60 p-4"><p className="text-2xl font-bold text-emerald-300">24×7</p><p className="mt-1 text-[10px] tracking-wide text-slate-400">ACCESS</p></div><div className="rounded-xl bg-slate-900/60 p-4"><p className="text-2xl font-bold text-orange-300">112</p><p className="mt-1 text-[10px] tracking-wide text-slate-400">EMERGENCY</p></div></div>
            <p className="mt-4 text-xs leading-relaxed text-slate-400">For official case status, notices and filings, always follow the linked department portal.</p>
          </div>
        </div>
      </div>
    </section>
  )
}
