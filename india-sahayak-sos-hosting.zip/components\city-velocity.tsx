import { TrendingUp } from 'lucide-react'

const pulse = [42, 55, 48, 52, 46, 58, 50, 54, 47, 56, 49, 53, 45]
const traffic = [38, 44, 46, 40, 48, 43, 47, 42, 49, 44, 48, 45, 43]

function buildPath(data: number[], w: number, h: number) {
  const max = Math.max(...pulse, ...traffic)
  const min = Math.min(...pulse, ...traffic)
  const range = max - min || 1
  const step = w / (data.length - 1)
  return data
    .map((v, i) => `${i === 0 ? 'M' : 'L'} ${i * step} ${h - ((v - min) / range) * (h - 20) - 10}`)
    .join(' ')
}

export function CityVelocity() {
  const w = 900
  const h = 220
  return (
    <section className="rounded-2xl border border-border/80 bg-card p-6">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight">City velocity</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            A 12-hour view of movement pressure and pulse confidence
          </p>
        </div>
        <TrendingUp className="h-5 w-5 text-primary" />
      </div>

      <div className="mt-4 flex items-center gap-5 font-mono text-[11px] tracking-[0.12em] text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-primary" /> PULSE
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-amber-400" /> TRAFFIC
        </span>
      </div>

      <div className="mt-4">
        <svg viewBox={`0 0 ${w} ${h}`} className="h-56 w-full" preserveAspectRatio="none">
          {[0.25, 0.5, 0.75].map((f) => (
            <line
              key={f}
              x1={0}
              x2={w}
              y1={h * f}
              y2={h * f}
              stroke="oklch(1 0 0 / 0.06)"
              strokeWidth={1}
            />
          ))}
          <path
            d={buildPath(pulse, w, h)}
            fill="none"
            stroke="oklch(0.82 0.13 195)"
            strokeWidth={2.5}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d={buildPath(traffic, w, h)}
            fill="none"
            stroke="oklch(0.78 0.16 85)"
            strokeWidth={2.5}
            strokeDasharray="6 6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
        <div className="mt-2 flex justify-between font-mono text-[10px] text-muted-foreground">
          <span>00:23</span>
          <span>06:23</span>
          <span>11:23</span>
        </div>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        Normalized hourly snapshots · not a forecast
      </p>
    </section>
  )
}
