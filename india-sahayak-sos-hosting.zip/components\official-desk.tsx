import { ExternalLink, FileText, Landmark, PhoneCall } from 'lucide-react'

const portals = [
  ['CPGRAMS', 'Department of Administrative Reforms', 'Lodge and track a grievance against a government service.', 'https://pgportal.gov.in/'],
  ['MyGov India', 'Ministry of Electronics & IT', 'Participate in consultations, surveys and public discussions.', 'https://www.mygov.in/'],
  ['DigiLocker', 'Ministry of Electronics & IT', 'Access verified digital documents and certificates.', 'https://www.digilocker.gov.in/'],
  ['National Consumer Helpline', 'Department of Consumer Affairs', 'Register a consumer complaint and check its status.', 'https://consumerhelpline.gov.in/'],
  ['Cyber Crime Portal', 'Ministry of Home Affairs', 'Report online financial fraud and cybercrime.', 'https://cybercrime.gov.in/'],
  ['UMANG', 'National e-Governance Division', 'Find central and state citizen services in one place.', 'https://web.umang.gov.in/'],
]

export function OfficialDesk() {
  return (
    <section className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="grid h-11 w-11 place-items-center rounded-2xl bg-amber-400/10 text-amber-300"><Landmark className="h-5 w-5" /></div>
        <div><p className="font-mono text-[10px] tracking-[0.18em] text-amber-300">OFFICIAL CONNECTORS</p><h2 className="mt-1 text-2xl font-bold tracking-tight">Citizen services & ministries</h2></div>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {portals.map(([name, ministry, description, href]) => (
          <a key={name} href={href} target="_blank" rel="noreferrer" className="group rounded-2xl border border-border/80 bg-card p-5 transition-all hover:-translate-y-1 hover:border-primary/40 hover:shadow-xl hover:shadow-black/20">
            <div className="flex items-start justify-between gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-secondary text-primary"><FileText className="h-5 w-5" /></div><ExternalLink className="h-4 w-4 text-muted-foreground transition-colors group-hover:text-primary" /></div>
            <h3 className="mt-4 font-bold">{name}</h3>
            <p className="mt-1 font-mono text-[10px] tracking-[0.08em] text-primary">{ministry}</p>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{description}</p>
          </a>
        ))}
      </div>
      <div className="flex items-center gap-3 rounded-2xl border border-destructive/30 bg-destructive/10 p-4 text-sm">
        <PhoneCall className="h-5 w-5 shrink-0 text-destructive" />
        <span><strong>Emergency first:</strong> for immediate danger, call <a className="font-bold text-destructive underline" href="tel:112">112</a>. Portal links are informational and open official external websites.</span>
      </div>
    </section>
  )
}
