'use client'

import { ChangeEvent, FormEvent, useState } from 'react'
import { Award, CheckCircle2, FileBadge, HeartHandshake, Upload } from 'lucide-react'

const categories = ['Community service', 'Food distribution', 'Environment & cleanliness', 'Road safety', 'Health support', 'Digital literacy']

export function SocialPoints() {
  const [expanded, setExpanded] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [approved, setApproved] = useState(false)
  const [proof, setProof] = useState('')
  const [certificateId, setCertificateId] = useState('')
  const [form, setForm] = useState({ name: '', category: categories[0], duration: '', impact: '', location: '' })

  const update = (key: keyof typeof form, value: string) => setForm((current) => ({ ...current, [key]: value }))
  const submitApplication = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setSubmitted(true)
    setApproved(false)
    setCertificateId(`MYB-${Date.now().toString(36).toUpperCase()}`)
  }
  const addProof = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) setProof(file.name)
  }

  return (
    <section className="social-points-shell relative overflow-hidden rounded-2xl border border-emerald-400/20 p-4 sm:p-6">
      <div className="relative">
        <button type="button" onClick={() => setExpanded((value) => !value)} className="flex w-full items-center justify-between gap-4 text-left">
          <div className="flex items-center gap-3"><div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-400/15 text-emerald-300"><HeartHandshake className="h-5 w-5" /></div><div><p className="font-mono text-[10px] tracking-[0.18em] text-emerald-300">MY BHARAT COMMUNITY ACTION</p><h2 className="mt-1 text-lg font-bold">Submit your social work</h2></div></div>
          <span className="rounded-lg border border-emerald-400/25 px-3 py-2 text-xs font-semibold text-emerald-300">{expanded ? 'Close' : 'Apply now'}</span>
        </button>

        {expanded && (
          <div className="mt-6 grid gap-6 lg:grid-cols-[1.1fr_.9fr]">
            <form onSubmit={submitApplication} className="grid gap-3 rounded-2xl border border-border/80 bg-card/60 p-4 sm:grid-cols-2">
              <label className="field-label">Applicant name<input required value={form.name} onChange={(event) => update('name', event.target.value)} placeholder="Your full name" /></label>
              <label className="field-label">Work category<select value={form.category} onChange={(event) => update('category', event.target.value)}>{categories.map((category) => <option key={category}>{category}</option>)}</select></label>
              <label className="field-label">Work duration<input required value={form.duration} onChange={(event) => update('duration', event.target.value)} placeholder="e.g. 6 months" /></label>
              <label className="field-label">Work location<input required value={form.location} onChange={(event) => update('location', event.target.value)} placeholder="City / locality" /></label>
              <label className="field-label sm:col-span-2">Impact summary<textarea required value={form.impact} onChange={(event) => update('impact', event.target.value)} placeholder="Who did you help and what changed?" rows={3} /></label>
              <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-dashed border-emerald-400/40 p-3 text-xs font-semibold text-emerald-300 sm:col-span-2"><Upload className="h-4 w-4" />{proof || 'Upload photo or supporting proof'}<input required type="file" accept="image/*,.pdf" className="sr-only" onChange={addProof} /></label>
              <button type="submit" className="flex items-center justify-center gap-2 rounded-xl bg-emerald-400 px-4 py-3 text-sm font-bold text-emerald-950 sm:col-span-2"><Award className="h-4 w-4" />Submit for evaluation</button>
            </form>

            <div className="space-y-3">
              <div className="rounded-2xl border border-border/80 bg-card p-5"><p className="font-mono text-[10px] tracking-[0.16em] text-emerald-300">EVALUATION TRACKER</p><h3 className="mt-2 text-lg font-bold">Evidence-based recognition</h3><div className="mt-5 space-y-3">{['Application received', 'Evidence review', 'Certificate decision'].map((step, index) => <div key={step} className="flex items-center gap-3 text-sm"><span className={`grid h-7 w-7 place-items-center rounded-full ${submitted && index === 0 ? 'bg-emerald-400 text-emerald-950' : 'bg-secondary text-muted-foreground'}`}>{submitted && index === 0 ? <CheckCircle2 className="h-4 w-4" /> : index + 1}</span><span className={submitted && index === 0 ? 'font-semibold' : 'text-muted-foreground'}>{step}</span></div>)}</div>{submitted && <p className="mt-4 rounded-lg bg-amber-400/10 p-3 text-xs text-amber-200">Application {certificateId} is queued for prototype review.</p>}</div>
              {submitted && <div className="rounded-2xl border border-emerald-400/40 bg-emerald-400/10 p-5"><FileBadge className="h-7 w-7 text-emerald-300" /><p className="mt-3 font-bold text-emerald-200">Prototype certificate preview</p><p className="mt-1 text-xs text-muted-foreground">{form.name} · {form.category} · {form.duration}</p><button type="button" onClick={() => setApproved(true)} className="mt-4 rounded-lg bg-emerald-400 px-3 py-2 text-xs font-bold text-emerald-950">{approved ? 'Certificate marked ready' : 'Complete prototype evaluation'}</button>{approved && <p className="mt-3 flex items-center gap-2 text-xs text-emerald-200"><CheckCircle2 className="h-4 w-4" /> Recognition ID: {certificateId}</p>}</div>}
            </div>
          </div>
        )}
        <p className="mt-4 text-center font-mono text-[10px] tracking-[0.1em] text-muted-foreground">Prototype inspired by citizen-volunteering portals · not an official government approval system</p>
      </div>
    </section>
  )
}
