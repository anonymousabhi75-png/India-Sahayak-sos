import { LayoutGrid, PhoneCall, Hospital, ShieldAlert } from 'lucide-react'
import { BrandLogo } from '@/components/brand-logo'

const navItems = [
  { label: 'Services', icon: LayoutGrid, href: '#services' },
  { label: 'Hospitals', icon: Hospital, href: '#services' },
  { label: 'Emergency', icon: PhoneCall, href: '#services' },
]

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/80 bg-background/85 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6">
        <a href="#top" className="flex items-center gap-3">
          <BrandLogo className="h-10 w-10" />
          <div className="leading-none">
            <p className="text-sm font-bold tracking-tight">
              INDIA <span className="text-primary">SAHAYAK</span>
            </p>
            <p className="mt-1 font-mono text-[10px] tracking-[0.18em] text-muted-foreground">
              CIVIC ASSISTANCE / INDIA
            </p>
          </div>
        </a>

        <nav className="ml-4 hidden items-center gap-1 rounded-full border border-border/70 bg-card/60 p-1 md:flex">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="flex items-center gap-2 rounded-full px-3.5 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </a>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2 sm:gap-3">
          <a
            href="#sos"
            className="inline-flex items-center gap-2 rounded-full border border-destructive/40 bg-destructive/10 px-3.5 py-2 text-sm font-semibold text-destructive transition-colors hover:bg-destructive/20"
          >
            <ShieldAlert className="h-4 w-4" />
            <span className="hidden sm:inline">SOS</span> 112
          </a>
        </div>
      </div>
    </header>
  )
}
