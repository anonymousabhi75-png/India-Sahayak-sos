'use client'

import { Activity, ArrowUpRight, Baby, BellRing, Building2, CarFront, ShieldAlert, TrendingUp, Zap, X } from 'lucide-react'
import { useEffect, useState } from 'react'

const stats = [
  { label: 'City pulse score', value: '78 / 100', note: '+6.4% this month', icon: Activity, color: 'text-primary' },
  { label: 'Birth registrations', value: '4,892', note: '+4.1% this quarter', icon: Baby, color: 'text-emerald-300' },
  { label: 'Road incidents', value: '286', note: '−8.2% vs last month', icon: CarFront, color: 'text-amber-300' },
  { label: 'Civic projects', value: '64 active', note: '32 completed this year', icon: Building2, color: 'text-sky-300' },
]

const alerts = [
  { icon: Zap, title: 'Planned power maintenance', detail: 'Demo alert · check your discom for the official schedule', tone: 'text-yellow-300' },
  { icon: CarFront, title: 'Traffic advisory', detail: 'Demo alert · verify with the official traffic control room', tone: 'text-sky-300' },
  { icon: BellRing, title: 'Civic bulletin', detail: 'Official feeds can be connected here by city administrators', tone: 'text-primary' },
]

export function CityInsights() {
  const [notification, setNotification] = useState(true)
  const [liveTick, setLiveTick] = useState(0)

  useEffect(() => {
    const timer = window.setTimeout(() => setNotification(false), 7000)
    const refresh = window.setInterval(() => setLiveTick((value) => value + 1), 800)
    return () => {
      window.clearTimeout(timer)
      window.clearInterval(refresh)
    }
  }, [])

  const liveBirths = 4892 + liveTick * 2
  const livePoints = [35, 56, 48, 76, 64, 96, 82].map((point, index) => Math.max(24, Math.min(150, point + ((liveTick + index) % 4) * 3)))
  const livePath = livePoints.map((point, index) => `${index === 0 ? 'M' : 'L'}${index * 116.6} ${180 - point}`).join(' ')

  return (
    <section className="space-y-5">
      {notification && (
        <div className="animate-in slide-in-from-top-2 flex items-start gap-3 rounded-2xl border border-primary/30 bg-primary/10 p-4 shadow-lg shadow-primary/5">
          <BellRing className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
          <div className="flex-1"><p className="text-sm font-bold">CityPulse update ready</p><p className="mt-1 text-xs text-muted-foreground">Demo notification refreshed on page load. Verified official notices will appear here after a government feed is connected.</p></div>
          <button type="button" onClick={() => setNotification(false)} aria-label="Dismiss notification"><X className="h-4 w-4 text-muted-foreground" /></button>
        </div>
      )}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] tracking-[0.18em] text-primary">CITY INTELLIGENCE</p>
          <h2 className="mt-1 text-2xl font-bold tracking-tight">Your city, alive with signals</h2>
          <p className="mt-1.5 text-sm text-muted-foreground">Watch civic activity pulse with fast market-style refreshes as verified city data becomes available.</p>
        </div>
        <span className="inline-flex items-center gap-2 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1.5 font-mono text-[10px] tracking-[0.12em] text-emerald-300"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300" />FAST LIVE DEMO · 0.8S</span>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <article key={stat.label} className="insight-card rounded-2xl border border-border/80 bg-card p-5">
            <div className="flex items-start justify-between"><stat.icon className={`h-5 w-5 ${stat.color}`} /><ArrowUpRight className="h-4 w-4 text-muted-foreground" /></div>
            <p className="mt-5 text-sm text-muted-foreground">{stat.label}</p>
            <p className="mt-1 text-2xl font-bold tracking-tight">{stat.label === 'Birth registrations' ? liveBirths.toLocaleString('en-IN') : stat.value}</p>
            <p className="mt-2 flex items-center gap-1.5 text-xs text-emerald-300"><TrendingUp className="h-3 w-3" />{stat.note}</p>
          </article>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <article className="rounded-2xl border border-border/80 bg-card p-5 sm:p-6">
          <div className="flex items-center justify-between"><div><h3 className="font-bold">Registrations trend</h3><p className="mt-1 text-xs text-muted-foreground">Illustrative fast-refresh demo · updates every 0.8 seconds</p></div><span className="rounded-full bg-emerald-400/10 px-2.5 py-1 font-mono text-[10px] text-emerald-300">+4.1%</span></div>
          <div className="mt-5 h-44 w-full">
            <svg viewBox="0 0 700 180" className="h-full w-full" role="img" aria-label="Upward registrations trend graph">
              <defs><linearGradient id="area" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="oklch(0.82 0.13 195)" stopOpacity=".28" /><stop offset="100%" stopColor="oklch(0.82 0.13 195)" stopOpacity="0" /></linearGradient></defs>
              {[35, 75, 115, 155].map((y) => <line key={y} x1="0" x2="700" y1={y} y2={y} stroke="currentColor" className="text-border" strokeDasharray="4 7" />)}
              <path d={`${livePath} L700 180 L0 180 Z`} fill="url(#area)" />
              <path d={livePath} fill="none" stroke="oklch(0.82 0.13 195)" strokeWidth="4" strokeLinecap="round" />
              <circle cx="700" cy={180 - livePoints[6]} r="6" fill="oklch(0.82 0.13 195)" />
            </svg>
          </div>
          <div className="flex justify-between font-mono text-[10px] text-muted-foreground"><span>APR</span><span>MAY</span><span>JUN</span><span>JUL</span><span>AUG</span><span>SEP</span><span>NOW</span></div>
        </article>
        <article className="rounded-2xl border border-border/80 bg-card p-5 sm:p-6">
          <div className="flex items-center gap-2"><BellRing className="h-4 w-4 text-primary" /><h3 className="font-bold">City alerts</h3></div>
          <p className="mt-1 text-xs text-muted-foreground">Official alerts appear here when an approved feed is connected.</p>
          <div className="mt-4 space-y-3">{alerts.map((alert) => <div key={alert.title} className="rounded-xl border border-border/70 bg-background/35 p-3"><div className="flex items-center gap-2 text-sm font-semibold"><alert.icon className={`h-4 w-4 ${alert.tone}`} />{alert.title}</div><p className="mt-1 text-xs leading-relaxed text-muted-foreground">{alert.detail}</p></div>)}</div>
        </article>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <article className="rounded-2xl border border-border/80 bg-card p-5 sm:p-6">
          <div className="flex items-center justify-between"><div><h3 className="font-bold">Public service response</h3><p className="mt-1 text-xs text-muted-foreground">Illustrative resolved requests by department</p></div><span className="font-mono text-[10px] text-emerald-300">THIS MONTH</span></div>
          <div className="mt-5 space-y-4">
            {[['Electricity', 86, 'bg-yellow-300'], ['Water supply', 74, 'bg-sky-400'], ['Road repair', 68, 'bg-amber-300'], ['Health services', 91, 'bg-emerald-400'], ['Public safety', 79, 'bg-rose-400']].map(([label, value, color]) => <div key={label as string}><div className="mb-1.5 flex justify-between text-xs"><span className="text-muted-foreground">{label}</span><strong>{value}%</strong></div><div className="h-2 overflow-hidden rounded-full bg-secondary"><div className={`h-full rounded-full ${color}`} style={{ width: `${value}%` }} /></div></div>)}
          </div>
        </article>
        <article className="rounded-2xl border border-border/80 bg-card p-5 sm:p-6">
          <div className="flex items-center justify-between"><div><h3 className="font-bold">Safety & mobility index</h3><p className="mt-1 text-xs text-muted-foreground">Comparative city signal score</p></div><Activity className="h-4 w-4 text-emerald-300" /></div>
          <div className="mt-5 space-y-4">
            {[['Road safety', 82, 'bg-sky-400'], ['Emergency response', 76, 'bg-emerald-400'], ['Public mobility', 69, 'bg-amber-300'], ['Civic resolution', 88, 'bg-primary']].map(([label, value, color]) => <div key={label as string}><div className="mb-1.5 flex justify-between text-xs"><span className="text-muted-foreground">{label}</span><strong>{value}</strong></div><div className="h-2 overflow-hidden rounded-full bg-secondary"><div className={`h-full rounded-full ${color}`} style={{ width: `${value}%` }} /></div></div>)}
          </div>
        </article>
      </div>
      <p className="flex items-center gap-2 text-[11px] text-muted-foreground"><ShieldAlert className="h-3.5 w-3.5 text-amber-300" />Current dashboard values are illustrative. Live government data requires official API/feed access and will not be fabricated.</p>
    </section>
  )
}
