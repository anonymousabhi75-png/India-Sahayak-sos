'use client'

import { useMemo, useState } from 'react'
import {
  ArrowLeft,
  ChevronRight,
  Phone,
  Search,
  MapPin,
  Clock,
  Stethoscope,
  LayoutGrid,
} from 'lucide-react'
import { categories, type Category, type Listing } from '@/lib/city-data'

export function CityServices() {
  const [activeId, setActiveId] = useState<string | null>(null)
  const [query, setQuery] = useState('')

  const active = categories.find((c) => c.id === activeId) ?? null

  return (
    <section id="services" className="scroll-mt-24 space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <LayoutGrid className="h-6 w-6 text-primary" />
            <h2 className="text-2xl font-bold tracking-tight">City services desk</h2>
            <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-0.5 font-mono text-[10px] tracking-[0.12em] text-emerald-300">
              MULTI-CITY
            </span>
          </div>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Tap any service to see hospitals, helplines, doctors and direct contact numbers in your
            city.
          </p>
        </div>
      </div>

      {active ? (
        <CategoryDetail category={active} onBack={() => setActiveId(null)} />
      ) : (
        <CategoryGrid query={query} setQuery={setQuery} onOpen={setActiveId} />
      )}
    </section>
  )
}

function CategoryGrid({
  query,
  setQuery,
  onOpen,
}: {
  query: string
  setQuery: (v: string) => void
  onOpen: (id: string) => void
}) {
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return categories
    return categories.filter(
      (c) =>
        c.label.toLowerCase().includes(q) ||
        c.short.toLowerCase().includes(q) ||
        c.listings.some((l) => l.name.toLowerCase().includes(q)),
    )
  }, [query])

  return (
    <div className="space-y-5">
      <div className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search a service — hospitals, electricity, water, SOS..."
          className="w-full rounded-xl border border-border/70 bg-card py-3.5 pl-11 pr-4 text-sm outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary/50"
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((c) => (
          <button
            key={c.id}
            onClick={() => onOpen(c.id)}
            className="group flex flex-col rounded-2xl border border-border/80 bg-card p-5 text-left transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-lg hover:shadow-black/20"
          >
            <div className="flex items-start justify-between">
              <div
                className={`grid h-12 w-12 place-items-center rounded-xl ${c.glow} ${c.ring} border`}
              >
                <c.icon className={`h-6 w-6 ${c.accent}`} />
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:text-primary" />
            </div>
            <h3 className="mt-4 text-lg font-bold">{c.label}</h3>
            <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{c.short}</p>
            <span className="mt-4 inline-flex items-center gap-1.5 font-mono text-[10px] tracking-[0.12em] text-muted-foreground/80">
              {c.listings.length} listings
            </span>
          </button>
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="rounded-xl border border-border/60 bg-card p-8 text-center text-sm text-muted-foreground">
          No service matches &quot;{query}&quot;. Try another keyword.
        </p>
      )}
    </div>
  )
}

function CategoryDetail({ category, onBack }: { category: Category; onBack: () => void }) {
  const [query, setQuery] = useState('')

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return category.listings
    return category.listings.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.area?.toLowerCase().includes(q) ||
        l.note?.toLowerCase().includes(q) ||
        l.doctors?.some((d) => d.specialty.toLowerCase().includes(q) || d.name.toLowerCase().includes(q)),
    )
  }, [category, query])

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-4 rounded-2xl border border-border/80 bg-card p-5 sm:p-6">
        <div className="flex items-start gap-4">
          <button
            onClick={onBack}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-border/70 text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
            aria-label="Back to all services"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div
            className={`grid h-12 w-12 shrink-0 place-items-center rounded-xl ${category.glow} ${category.ring} border`}
          >
            <category.icon className={`h-6 w-6 ${category.accent}`} />
          </div>
          <div>
            <h3 className="text-xl font-bold tracking-tight">{category.label}</h3>
            <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
              {category.description}
            </p>
          </div>
        </div>

        {category.helplines && category.helplines.length > 0 && (
          <div className="flex flex-wrap gap-2 border-t border-border/60 pt-4">
            {category.helplines.map((h) => (
              <a
                key={h.number}
                href={`tel:${h.number}`}
                className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3.5 py-1.5 text-sm font-semibold text-primary transition-colors hover:bg-primary/20"
              >
                <Phone className="h-3.5 w-3.5" />
                {h.label}
                <span className="font-mono">{h.number}</span>
              </a>
            ))}
          </div>
        )}

        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={`Search within ${category.label.toLowerCase()}...`}
            className="w-full rounded-xl border border-border/70 bg-background/50 py-3 pl-11 pr-4 text-sm outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-primary/50"
          />
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {filtered.map((l) => (
          <ListingCard key={l.name} listing={l} accent={category.accent} />
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="rounded-xl border border-border/60 bg-card p-8 text-center text-sm text-muted-foreground">
          Nothing here matches &quot;{query}&quot;.
        </p>
      )}
    </div>
  )
}

function ListingCard({ listing, accent }: { listing: Listing; accent: string }) {
  return (
    <article className="flex flex-col rounded-2xl border border-border/80 bg-card p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h4 className="text-base font-bold leading-snug">{listing.name}</h4>
          {listing.area && (
            <p className="mt-1 inline-flex items-center gap-1.5 text-sm text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              {listing.area}
            </p>
          )}
        </div>
        {listing.open247 && (
          <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-0.5 font-mono text-[10px] tracking-[0.1em] text-emerald-300">
            <Clock className="h-3 w-3" />
            24x7
          </span>
        )}
      </div>

      {listing.address && (
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{listing.address}</p>
      )}
      {listing.note && (
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{listing.note}</p>
      )}

      {listing.tags && listing.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {listing.tags.map((t) => (
            <span
              key={t}
              className="rounded-full border border-border/70 bg-background/50 px-2.5 py-0.5 text-[11px] text-muted-foreground"
            >
              {t}
            </span>
          ))}
        </div>
      )}

      {listing.doctors && listing.doctors.length > 0 && (
        <div className="mt-4 space-y-2 rounded-xl border border-border/60 bg-background/40 p-3">
          <p className="flex items-center gap-1.5 font-mono text-[10px] tracking-[0.14em] text-muted-foreground">
            <Stethoscope className="h-3.5 w-3.5" />
            SPECIALISTS
          </p>
          {listing.doctors.map((d) => (
            <div key={d.name} className="flex items-center justify-between gap-3 text-sm">
              <span>
                <span className="font-medium">{d.name}</span>
                <span className="ml-1.5 text-muted-foreground">· {d.specialty}</span>
              </span>
              <a
                href={`tel:${d.phone}`}
                className={`inline-flex items-center gap-1 font-mono text-xs ${accent} transition-opacity hover:opacity-80`}
              >
                <Phone className="h-3 w-3" />
                {d.phone}
              </a>
            </div>
          ))}
        </div>
      )}

      {listing.phone && (
        <a
          href={`tel:${listing.phone}`}
          className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.01]"
        >
          <Phone className="h-4 w-4" />
          Call {listing.phone}
        </a>
      )}
    </article>
  )
}
