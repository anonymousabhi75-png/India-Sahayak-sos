import { Gauge, CloudSun, Navigation } from 'lucide-react'

function Sparkline({ color, seed }: { color: string; seed: number[] }) {
  const max = Math.max(...seed)
  const min = Math.min(...seed)
  const range = max - min || 1
  const w = 180
  const h = 48
  const step = w / (seed.length - 1)
  const points = seed
    .map((v, i) => `${i * step},${h - ((v - min) / range) * (h - 6) - 3}`)
    .join(' ')
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-12 w-full" preserveAspectRatio="none" aria-hidden>
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export function StatCards() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {/* City pulse index */}
      <article className="rounded-2xl border border-border/80 bg-card p-5">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] tracking-[0.16em] text-muted-foreground">
            CITY PULSE INDEX
          </span>
          <Gauge className="h-4 w-4 text-primary" />
        </div>
        <div className="mt-5 flex items-end gap-3">
          <span className="text-5xl font-bold tracking-tight">57</span>
          <span className="mb-2 rounded-md bg-emerald-400/15 px-2 py-0.5 text-xs font-semibold text-emerald-300">
            Watch
          </span>
        </div>
        <div className="mt-5 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
          <div
            className="h-full w-[57%] rounded-full"
            style={{
              background:
                'linear-gradient(90deg, oklch(0.7 0.19 22), oklch(0.78 0.16 85), oklch(0.75 0.16 145))',
            }}
          />
        </div>
        <div className="mt-2 flex justify-between font-mono text-[10px] text-muted-foreground">
          <span>0 strained</span>
          <span>100 healthy</span>
        </div>
      </article>

      {/* Micro-climate */}
      <article className="rounded-2xl border border-border/80 bg-card p-5">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] tracking-[0.16em] text-muted-foreground">
            MICRO-CLIMATE
          </span>
          <CloudSun className="h-4 w-4 text-amber-300" />
        </div>
        <div className="mt-4 flex items-end justify-between gap-2">
          <div>
            <p className="text-4xl font-bold tracking-tight">
              34<span className="align-top text-xl">°C</span>
            </p>
            <p className="mt-1 text-sm text-muted-foreground">Clear skies</p>
          </div>
          <div className="w-1/2">
            <Sparkline color="oklch(0.78 0.16 85)" seed={[3, 8, 4, 9, 5, 8, 4, 7, 3]} />
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">≈ 5 km/h wind</span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-300">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> LIVE
          </span>
        </div>
      </article>

      {/* Air quality */}
      <article className="rounded-2xl border border-border/80 bg-card p-5">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] tracking-[0.16em] text-muted-foreground">
            AIR QUALITY
          </span>
          <span className="h-2.5 w-2.5 rounded-full bg-destructive" />
        </div>
        <div className="mt-4 flex items-end justify-between">
          <div>
            <p className="text-5xl font-bold tracking-tight">169</p>
            <p className="mt-1 text-sm text-destructive/90">Poor · US AQI</p>
          </div>
          <div className="text-right font-mono text-[11px] leading-relaxed text-muted-foreground">
            <p>
              PM2.5 <span className="font-semibold text-foreground">38.4</span>
            </p>
            <p>
              PM10 <span className="font-semibold text-foreground">49.1</span>
            </p>
          </div>
        </div>
        <div className="mt-4">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-300">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> LIVE SENSOR
          </span>
        </div>
      </article>

      {/* Movement pulse */}
      <article className="rounded-2xl border border-border/80 bg-card p-5">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] tracking-[0.16em] text-muted-foreground">
            MOVEMENT PULSE
          </span>
          <Navigation className="h-4 w-4 text-primary" />
        </div>
        <div className="mt-4 flex items-end justify-between gap-2">
          <div>
            <p className="text-4xl font-bold tracking-tight">54%</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Moving · <span className="text-foreground">+18</span> min delay
            </p>
          </div>
          <div className="w-1/2">
            <Sparkline color="oklch(0.72 0.15 300)" seed={[5, 9, 4, 8, 5, 9, 6, 8, 4]} />
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">Free-flow delta</span>
          <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-400/10 px-2.5 py-0.5 text-[11px] font-semibold text-amber-300">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-400" /> DEMO FEED
          </span>
        </div>
      </article>
    </div>
  )
}
